/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight, Play, Cpu, Sparkles } from "lucide-react";

import SlideChallenges from "./slides/SlideChallenges";
import SlidePrinciples from "./slides/SlidePrinciples";
import SlideStoryIntelligence from "./slides/SlideStoryIntelligence";
import SlideCodeDevelopment from "./slides/SlideCodeDevelopment";
import SlideBenefits from "./slides/SlideBenefits";
import SlideFutureVision from "./slides/SlideFutureVision";

const SLIDES = [
  { id: 0, label: "01 VULNERABILITIES", title: "Current Challenges" },
  { id: 1, label: "02 METHODOLOGY", title: "Core Principles" },
  { id: 2, label: "03 REQS PARSING", title: "User Stories" },
  { id: 3, label: "04 ENGINE SYNTHESIS", title: "Autonomous Dev" },
  { id: 4, label: "05 VALUE IMPACT", title: "Enterprise Outcomes" },
  { id: 5, label: "06 FUTURE ECOSYSTEM", title: "Strategic Vision" }
];

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [direction, setDirection] = useState<"next" | "prev">("next");
  const [autoplay, setAutoplay] = useState(true);
  const [hoverLeft, setHoverLeft] = useState(false);
  const [hoverRight, setHoverRight] = useState(false);
  const [progress, setProgress] = useState(0);

  const autoplayTimer = useRef<NodeJS.Timeout | null>(null);
  const progressTimer = useRef<number | null>(null);

  const TOTAL_SLIDES = SLIDES.length;
  const AUTOPLAY_DURATION = 15000; // 15 seconds per slide for majestic pacing

  // Handle manual navigation
  const nextSlide = () => {
    setDirection("next");
    setCurrentSlide((prev) => (prev + 1) % TOTAL_SLIDES);
    setAutoplay(false); // Pause autoplay once user interacts
    setProgress(0);
  };

  const prevSlide = () => {
    setDirection("prev");
    setCurrentSlide((prev) => (prev - 1 + TOTAL_SLIDES) % TOTAL_SLIDES);
    setAutoplay(false); // Pause autoplay once user interacts
    setProgress(0);
  };

  const jumpToSlide = (idx: number) => {
    if (idx === currentSlide) return;
    setDirection(idx > currentSlide ? "next" : "prev");
    setCurrentSlide(idx);
    setAutoplay(false); // Pause autoplay once user interacts
    setProgress(0);
  };

  // Autoplay progression ticking
  useEffect(() => {
    if (!autoplay) {
      setProgress(0);
      return;
    }

    const intervalStep = 100; // tick every 100ms
    const totalSteps = AUTOPLAY_DURATION / intervalStep;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      const nextProgress = (currentStep / totalSteps) * 100;
      setProgress(Math.min(nextProgress, 100));

      if (currentStep >= totalSteps) {
        setDirection("next");
        setCurrentSlide((prev) => (prev + 1) % TOTAL_SLIDES);
        currentStep = 0;
        setProgress(0);
      }
    }, intervalStep);

    return () => clearInterval(timer);
  }, [currentSlide, autoplay]);

  // Hook up keyboard arrow listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "Space") {
        nextSlide();
      } else if (e.key === "ArrowLeft" || e.key === "Backspace") {
        prevSlide();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const renderSlide = () => {
    switch (currentSlide) {
      case 0:
        return <SlideChallenges isActive={true} />;
      case 1:
        return <SlidePrinciples isActive={true} />;
      case 2:
        return <SlideStoryIntelligence isActive={true} />;
      case 3:
        return <SlideCodeDevelopment isActive={true} />;
      case 4:
        return <SlideBenefits isActive={true} />;
      case 5:
        return <SlideFutureVision isActive={true} />;
      default:
        return <SlideChallenges isActive={true} />;
    }
  };

  return (
    <div className="relative w-screen h-screen bg-[#030303] text-white overflow-hidden font-sans select-none flex flex-col justify-between">
      
      {/* Decorative Top Enterprise Border Bar */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-red-500/40 via-cyan-500/40 via-indigo-500/40 to-purple-500/40 z-50" />

      {/* Slide Canvas Wrapper */}
      <div className="relative w-full h-full flex-grow overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ 
              opacity: 0, 
              x: direction === "next" ? 80 : -80,
              scale: 0.98
            }}
            animate={{ 
              opacity: 1, 
              x: 0,
              scale: 1
            }}
            exit={{ 
              opacity: 0, 
              x: direction === "next" ? -80 : 80,
              scale: 0.98
            }}
            transition={{ 
              duration: 0.7, 
              ease: [0.16, 1, 0.3, 1] // Beautiful cinematic bezier curve
            }}
            className="w-full h-full"
          >
            {renderSlide()}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Cinematic Sidebar Indicator / Overlay Bezel controls */}
      {/* LEFT ZONE TARGET */}
      <div 
        onMouseEnter={() => setHoverLeft(true)}
        onMouseLeave={() => setHoverLeft(false)}
        onClick={prevSlide}
        className="absolute left-0 top-0 bottom-0 w-24 z-30 cursor-pointer flex items-center justify-start pl-6 group pointer-events-auto"
      >
        <AnimatePresence>
          {hoverLeft && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 0.6, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              whileHover={{ scale: 1.1, opacity: 0.9 }}
              className="p-3 rounded-full bg-white/5 border border-white/10 backdrop-blur-md text-white/80 transition-shadow hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
            >
              <ChevronLeft className="w-5 h-5" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* RIGHT ZONE TARGET */}
      <div 
        onMouseEnter={() => setHoverRight(true)}
        onMouseLeave={() => setHoverRight(false)}
        onClick={nextSlide}
        className="absolute right-0 top-0 bottom-0 w-24 z-30 cursor-pointer flex items-center justify-end pr-6 group pointer-events-auto"
      >
        <AnimatePresence>
          {hoverRight && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 0.6, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              whileHover={{ scale: 1.1, opacity: 0.9 }}
              className="p-3 rounded-full bg-white/5 border border-white/10 backdrop-blur-md text-white/80 transition-shadow hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
            >
              <ChevronRight className="w-5 h-5" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Sleek Floating Keynote Progress indicators (At the very bottom edge) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-40 w-[90%] md:w-[70%] lg:w-[60%] flex flex-col items-center space-y-2 pointer-events-auto">
        
        {/* HUD Slide capsule segments */}
        <div className="w-full flex justify-between items-center bg-[#09090b]/80 border border-white/10 backdrop-blur-xl p-1.5 rounded-full shadow-[0_15px_30px_rgba(0,0,0,0.8)] backdrop-saturate-150">
          {SLIDES.map((slide, idx) => {
            const isSelected = currentSlide === idx;
            return (
              <button
                key={slide.id}
                onClick={() => jumpToSlide(idx)}
                className={`relative flex-1 group focus:outline-none transition-all duration-300 py-1.5 px-2 md:px-3 text-[10px] font-mono tracking-wider rounded-full flex flex-col justify-center items-center ${
                  isSelected 
                    ? "text-[#fafafa] font-semibold" 
                    : "text-gray-400/70 hover:text-white"
                }`}
              >
                <div className="text-center truncate w-full pointer-events-none">
                  {slide.label}
                </div>

                {/* Individual slide auto-progress or solid active indicator */}
                <div className="w-[85%] h-[2px] bg-white/[0.04] mt-1 relative rounded-full overflow-hidden">
                  {isSelected && autoplay ? (
                    <motion.div 
                      className="absolute inset-y-0 left-0 bg-cyan-400"
                      style={{ width: `${progress}%` }}
                    />
                  ) : isSelected ? (
                    <div className="absolute inset-0 bg-indigo-400" />
                  ) : null}
                </div>
              </button>
            );
          })}
        </div>

        {/* Dynamic Auto-play Indicator (No play/pause buttons, just simple status text) */}
        {autoplay && (
          <div className="flex items-center space-x-2 text-[9px] font-mono tracking-[0.2em] text-cyan-400/50">
            <Cpu className="w-3 h-3 animate-spin" style={{ animationDuration: "12s" }} />
            <span>CINEMATIC AUTO-PLAYING SERIES DIRECTED BY CORE PRINCIPLES</span>
          </div>
        )}
        {!autoplay && (
          <div className="flex items-center space-x-2 text-[9px] font-mono tracking-[0.2em] text-indigo-400/50">
            <Sparkles className="w-3 h-3" />
            <span>MANUAL INTERACTIVE HUDS STANDBY • PRESS ARROWS FOR SPEED RUN</span>
          </div>
        )}
      </div>

    </div>
  );
}
