import React from "react";
import { motion } from "motion/react";
import { 
  Brain, 
  Code2, 
  Terminal, 
  ShieldCheck, 
  CloudLightning, 
  Activity,
  Globe,
  Sparkles
} from "lucide-react";
import { SlideProps } from "../types";

export default function SlideFutureVision({ isActive }: SlideProps) {
  if (!isActive) return null;

  const orbitingSystems = [
    {
      title: "Requirements Intelligence",
      desc: "Instant intent parsing & trace matching",
      icon: Brain,
      top: "18%",
      left: "50%",
      color: "from-purple-500/20 to-fuchsia-600/30",
      borderColor: "border-fuchsia-500/30",
      glow: "shadow-fuchsia-500/10",
      delay: 0.1,
      floatingOffset: 0
    },
    {
      title: "Agentic Development",
      desc: "Federated agents code & build assembly",
      icon: Code2,
      top: "43%",
      left: "80%",
      color: "from-blue-500/20 to-cyan-600/30",
      borderColor: "border-cyan-500/30",
      glow: "shadow-cyan-500/10",
      delay: 0.2,
      floatingOffset: 120
    },
    {
      title: "Autonomous Testing",
      desc: "Lint validations & smart logical coverage",
      icon: Terminal,
      top: "76%",
      left: "68%",
      color: "from-teal-500/20 to-emerald-600/30",
      borderColor: "border-emerald-500/30",
      glow: "shadow-emerald-500/10",
      delay: 0.3,
      floatingOffset: 240
    },
    {
      title: "Governance Engine",
      desc: "Sanitization of code drafts & structural checks",
      icon: ShieldCheck,
      top: "76%",
      left: "32%",
      color: "from-emerald-500/20 to-teal-600/30",
      borderColor: "border-teal-500/30",
      glow: "shadow-teal-500/10",
      delay: 0.4,
      floatingOffset: 360
    },
    {
      title: "Deployment Automation",
      desc: "Progressive rollouts & serverless ingress",
      icon: CloudLightning,
      top: "43%",
      left: "20%",
      color: "from-pink-500/20 to-rose-600/30",
      borderColor: "border-rose-500/30",
      glow: "shadow-rose-500/10",
      delay: 0.5,
      floatingOffset: 480
    },
    {
      title: "Observability & Self-Healing",
      desc: "Anomalies diagnostics & dynamic recovery edits",
      icon: Activity,
      top: "18%",
      left: "35%",
      color: "from-cyan-500/20 to-blue-600/30",
      borderColor: "border-blue-500/30",
      glow: "shadow-blue-500/10",
      delay: 0.6,
      floatingOffset: 600
    }
  ];

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-12 md:p-16 select-none bg-gradient-to-b from-[#030303] via-[#09090b] to-[#030303] overflow-hidden">
      
      {/* Background Neural Grid Mesh */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] bg-purple-950/15 rounded-full blur-[140px] mix-blend-screen animate-pulse" style={{ animationDuration: "14s" }} />
        <div className="grid-bg absolute inset-0 opacity-20 pointer-events-none" />
      </div>

      {/* Header */}
      <div className="relative z-10 space-y-3">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex items-center space-x-2"
        >
          <span className="h-[1px] w-8 bg-gradient-to-r from-purple-500 to-transparent"></span>
          <span className="text-xs font-mono tracking-[0.3em] font-semibold text-purple-400 uppercase">
            Phase 06 — Strategic Vision
          </span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
          className="text-4xl md:text-5xl lg:text-6xl font-display font-light tracking-tight text-white max-w-4xl"
        >
          The Future of <span className="font-semibold bg-gradient-to-r from-white via-purple-100 to-purple-400 bg-clip-text text-transparent">Enterprise Software Delivery</span>
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="text-gray-400 text-sm md:text-base tracking-wide max-w-xl font-light"
        >
          Human-guided autonomous engineering powered by intelligent and highly governed AI orchestration.
        </motion.p>
      </div>

      {/* Main Orbital Ecosystem Visualization */}
      <div className="relative w-full flex-grow flex items-center justify-center min-h-[360px] lg:min-h-[430px]">
        
        {/* concentric orbital rings */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
          <defs>
            <linearGradient id="orbitGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(168, 85, 247, 0.15)" />
              <stop offset="50%" stopColor="rgba(6, 182, 212, 0.05)" />
              <stop offset="100%" stopColor="rgba(244, 63, 94, 0.1)" />
            </linearGradient>
          </defs>

          {/* Core planetary orbital paths */}
          <circle cx="50%" cy="50%" r="160" fill="none" stroke="url(#orbitGrad)" strokeWidth="1.5" strokeDasharray="4 8 animate-spin" className="origin-center animate-spin" style={{ animationDuration: "120s" }} />
          <circle cx="50%" cy="50%" r="240" fill="none" stroke="url(#orbitGrad)" strokeWidth="1" strokeDasharray="6 12" />
        </svg>

        {/* Center Node: AI Orchestration Platform */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2 }}
          className="relative z-10 flex flex-col items-center justify-center p-6 rounded-full border border-purple-500/20 bg-[#08080c]/95 w-36 h-36 md:w-44 md:h-44 text-center shadow-[0_0_70px_rgba(168,85,247,0.18)] group"
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-purple-500/5 to-transparent animate-spin" style={{ animationDuration: "10s" }} />
          <Globe className="w-8 h-8 text-purple-400 mb-1.5 animate-pulse" />
          <span className="text-[9px] font-mono tracking-[0.2em] text-purple-400 font-bold uppercase pointer-events-none">CONTROL PLANE</span>
          <span className="text-xs md:text-sm font-semibold text-white tracking-wide mt-1 font-display leading-tight pointer-events-none">AI Orchestration<br />Platform</span>
        </motion.div>

        {/* Orbit Systems */}
        {orbitingSystems.map((sys, idx) => {
          const SysIcon = sys.icon;
          return (
            <motion.div
              key={idx}
              className="absolute z-10 flex flex-col p-4 rounded-2xl border border-white/[0.05] bg-[#0c0c0f]/90 hover:bg-[#121217]/95 transition-all duration-300 w-52 md:w-60"
              style={{
                top: sys.top,
                left: sys.left,
                transform: "translate(-50%, -50%)",
              }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ 
                opacity: 1, 
                scale: 1,
                // Soft orbital floating math movement
                // This makes it feel incredibly fluid and real!
                y: [0, -6, 6, 0],
                x: [0, 4, -4, 0]
              }}
              transition={{ 
                opacity: { delay: sys.delay, duration: 0.8 },
                scale: { delay: sys.delay, duration: 0.8 },
                // slow smooth float
                y: {
                  repeat: Infinity,
                  duration: 6 + idx,
                  ease: "easeInOut",
                  delay: idx * 0.4
                },
                x: {
                  repeat: Infinity,
                  duration: 7 + idx,
                  ease: "easeInOut",
                  delay: idx * 0.2
                }
              }}
              whileHover={{ 
                scale: 1.05, 
                borderColor: "rgba(168, 85, 247, 0.35)",
                boxShadow: "0 10px 30px -10px rgba(168, 85, 247, 0.15)"
              }}
            >
              <div className="flex items-center space-x-3 mb-2">
                <div className={`p-1.5 rounded-lg bg-gradient-to-br ${sys.color} border ${sys.borderColor} flex-shrink-0`}>
                  <SysIcon className="w-3.5 h-3.5 text-purple-400" />
                </div>
                <h3 className="text-xs md:text-sm font-semibold text-white tracking-wide font-display mt-0.5 leading-snug">{sys.title}</h3>
              </div>
              <p className="text-[10px] md:text-xs text-gray-400 leading-normal font-light">{sys.desc}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Bottom Statement Section */}
      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between border-t border-white/[0.04] pt-6 gap-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex items-center space-x-3"
        >
          <div className="p-1 rounded bg-purple-950/40 border border-purple-500/20">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <p className="text-xs font-mono uppercase tracking-widest text-purple-400 font-bold">
            Autonomous Future State
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-right"
        >
          <p className="text-sm md:text-base font-display font-light text-gray-300">
            “The future is not AI replacing engineers — but <span className="font-medium text-white">governed human-AI collaboration</span> at enterprise scale.”
          </p>
        </motion.div>
      </div>
    </div>
  );
}
