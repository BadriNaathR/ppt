import React from "react";
import { motion } from "motion/react";
import { 
  Zap, 
  RotateCcw, 
  CheckSquare, 
  Scale, 
  Settings, 
  Activity, 
  TrendingUp,
  LineChart
} from "lucide-react";
import { SlideProps } from "../types";

export default function SlideBenefits({ isActive }: SlideProps) {
  if (!isActive) return null;

  const benefits = [
    {
      stat: "10x",
      title: "Faster Delivery Cycles",
      desc: "Instant specs compilation to deploy pipelines.",
      icon: Zap,
      accent: "from-cyan-500/10 to-cyan-500/20",
      borderColor: "border-cyan-500/20 hover:border-cyan-400/40",
      iconColor: "text-cyan-400",
      delay: 0.1,
    },
    {
      stat: "94%",
      title: "Reduced Rework Code",
      desc: "Spec first guarantees zero-drift alignment.",
      icon: RotateCcw,
      accent: "from-blue-500/10 to-blue-500/20",
      borderColor: "border-blue-500/20 hover:border-blue-400/40",
      iconColor: "text-blue-400",
      delay: 0.2,
    },
    {
      stat: "100%",
      title: "Active Traceability",
      desc: "Transparent lineage audits from BRD to Cloud Run.",
      icon: CheckSquare,
      accent: "from-indigo-500/10 to-indigo-500/20",
      borderColor: "border-indigo-500/20 hover:border-indigo-400/40",
      iconColor: "text-indigo-400",
      delay: 0.3,
    },
    {
      stat: "Zero",
      title: "Governed AI Delivery",
      desc: "Guarded output sanitization and safety rails.",
      icon: Scale,
      accent: "from-purple-500/10 to-purple-500/20",
      borderColor: "border-purple-500/20 hover:border-purple-400/40",
      iconColor: "text-purple-400",
      delay: 0.4,
    },
    {
      stat: "Grid",
      title: "Scalable Engineering",
      desc: "Federated agent swarms tackle complex systems.",
      icon: Settings,
      accent: "from-pink-500/10 to-pink-500/20",
      borderColor: "border-pink-500/20 hover:border-pink-400/40",
      iconColor: "text-pink-400",
      delay: 0.5,
    },
    {
      stat: "+250%",
      title: "Developer Productivity",
      desc: "Freed engineers focus on core business logic.",
      icon: TrendingUp,
      accent: "from-emerald-500/10 to-emerald-500/20",
      borderColor: "border-emerald-500/20 hover:border-emerald-400/40",
      iconColor: "text-emerald-400",
      delay: 0.6,
    },
  ];

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-12 md:p-16 select-none bg-gradient-to-b from-[#030303] via-[#09090b] to-[#030303] overflow-hidden">
      
      {/* Background soft lasers, stats charts */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-emerald-950/10 rounded-full blur-[130px] mix-blend-screen animate-pulse" style={{ animationDuration: "14s" }} />
        <div className="grid-bg absolute inset-0 opacity-15 pointer-events-none" />
        
        {/* Subtle geometric lines scaling up */}
        <svg className="absolute bottom-12 left-12 right-12 h-64 w-full opacity-5">
          <path d="M0,190 Q90,50 180,110 T360,10 T540,150 T720,40 T900,180" fill="none" stroke="rgba(16, 185, 129, 0.4)" strokeWidth="3" />
          <path d="M0,150 Q90,120 180,140 T360,110 T540,60 T720,150 T900,100" fill="none" stroke="rgba(6, 182, 212, 0.4)" strokeWidth="2" strokeDasharray="5 5" />
        </svg>
      </div>

      {/* Header */}
      <div className="relative z-10 space-y-3">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex items-center space-x-2"
        >
          <span className="h-[1px] w-8 bg-gradient-to-r from-emerald-500 to-transparent"></span>
          <span className="text-xs font-mono tracking-[0.3em] font-semibold text-emerald-400 uppercase">
            Phase 05 — Strategic Impact
          </span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
          className="text-4xl md:text-5xl lg:text-6xl font-display font-light tracking-tight text-white max-w-4xl"
        >
          Enterprise <span className="font-semibold bg-gradient-to-r from-white via-emerald-100 to-emerald-400 bg-clip-text text-transparent">Transformation Outcomes</span>
        </motion.h1>
      </div>

      {/* 3x2 Bento grid structure */}
      <div className="relative z-10 flex-grow grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 items-center justify-center my-6 max-h-[360px] md:max-h-none overflow-y-auto pr-1">
        {benefits.map((benefit, idx) => {
          const BenefitIcon = benefit.icon || TrendingUp;
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: benefit.delay, duration: 0.8 }}
              whileHover={{ 
                y: -6, 
                transition: { duration: 0.2 } 
              }}
              className={`p-5 rounded-2xl border ${benefit.borderColor} bg-gradient-to-b from-[#0e0e12]/95 to-[#08080b]/95 backdrop-blur-md transition-all duration-300 shadow-[0_12px_24px_rgba(0,0,0,0.4)] flex flex-col justify-between h-[115px] group select-none`}
            >
              <div className="flex items-center justify-between">
                {/* Glowing Stat Number */}
                <span className={`text-2xl md:text-3xl font-display font-bold bg-gradient-to-r from-white via-gray-100 ${benefit.iconColor.replace('text-', 'to-')} bg-clip-text text-transparent tracking-tight`}>
                  {benefit.stat}
                </span>

                {/* Micro-Icon */}
                <div className={`p-1.5 rounded-lg bg-[#121217] border border-white/[0.04] group-hover:scale-110 transition-transform duration-300`}>
                  <BenefitIcon className={`w-4 h-4 ${benefit.iconColor}`} />
                </div>
              </div>

              <div>
                <h3 className="text-xs md:text-sm font-semibold text-white tracking-wide font-display group-hover:text-emerald-400 transition-colors">{benefit.title}</h3>
                <p className="text-[10px] md:text-xs text-gray-400/90 leading-snug font-light mt-0.5 truncate">{benefit.desc}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Bottom Statement Section */}
      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between border-t border-white/[0.04] pt-6 gap-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex items-center space-x-3"
        >
          <div className="p-1 rounded bg-emerald-950/40 border border-emerald-500/20">
            <LineChart className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <p className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
            Analytics & Value Engine
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-right"
        >
          <p className="text-sm md:text-base font-display font-light text-gray-300">
            “AI orchestration transforms software delivery into a <span className="font-medium text-white">scalable enterprise capability</span>.”
          </p>
        </motion.div>
      </div>
    </div>
  );
}
