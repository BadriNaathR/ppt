import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { 
  Brain, 
  ShieldAlert, 
  GitFork, 
  Code2, 
  UserMinus, 
  Network,
  AlertTriangle
} from "lucide-react";
import { SlideProps } from "../types";

// 1. Core Matrix - Gyroscopic representation icon
const AdvancedCoreIcon = () => (
  <div className="relative w-16 h-16 flex items-center justify-center pointer-events-none">
    {/* Clean outer rotating dashed vector rings */}
    <motion.div
      className="absolute inset-0 border border-dashed border-red-500/40 rounded-full"
      animate={{ rotate: 360 }}
      transition={{ repeat: Infinity, duration: 18, ease: "linear" }}
    />
    
    {/* Inner counter-rotating indicator dot */}
    <motion.div
      className="absolute w-12 h-12 border border-dotted border-red-400/50 rounded-full"
      animate={{ rotate: -360 }}
      transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
    />
    
    {/* Dynamic central breathing core */}
    <motion.div
      className="absolute w-7 h-7 bg-gradient-to-tr from-red-600 via-rose-500 to-amber-500 rounded-sm"
      animate={{ 
        scale: [1, 1.25, 1],
        rotate: [0, 90, 180, 270, 360],
        borderRadius: ["25%", "50%", "25%"]
      }}
      transition={{ 
        repeat: Infinity, 
        duration: 4, 
        ease: "easeInOut" 
      }}
      style={{ boxShadow: "0 0 20px rgba(239, 68, 68, 0.65)" }}
    />
  </div>
);

// Animated 1: Hallucinations Brain Icon
const AnimatedBrainIcon = () => (
  <div className="relative w-7 h-7 flex items-center justify-center">
    <motion.div
      className="absolute inset-[-4px] bg-rose-500/10 rounded-full blur-[4px]"
      animate={{
        scale: [0.8, 1.4, 0.8],
        opacity: [0.4, 0.8, 0.4]
      }}
      transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
    />
    <motion.div
      className="absolute inset-0 border border-red-500/20 rounded-full"
      animate={{
        scale: [1, 2, 1],
        opacity: [0.8, 0, 0.8]
      }}
      transition={{ repeat: Infinity, duration: 2.5, ease: "easeOut" }}
    />
    <motion.div
      animate={{
        y: [0, -3, 0, 3, 0],
        rotate: [-3, 3, -3],
        scale: [1, 1.08, 1]
      }}
      transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
    >
      <Brain className="w-4 h-4 text-red-400 drop-shadow-[0_0_8px_rgba(244,63,94,0.7)]" />
    </motion.div>
  </div>
);

// Animated 2: Governance Gaps Icon
const AnimatedGovernanceIcon = () => (
  <div className="relative w-7 h-7 flex items-center justify-center">
    <motion.div
      className="absolute inset-0 border border-amber-500/20 rounded-full"
      animate={{
        scale: [1, 1.3, 1],
        opacity: [0.7, 0.2, 0.7]
      }}
      transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
    />
    {/* Lock/shield shaking security scan */}
    <motion.div
      animate={{
        rotateY: [0, 180, 360],
        scale: [1, 1.1, 1]
      }}
      transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
    >
      <ShieldAlert className="w-4 h-4 text-amber-400 drop-shadow-[0_0_8px_rgba(245,158,11,0.7)]" />
    </motion.div>
  </div>
);

// Animated 3: Requirement Drift Icon
const AnimatedDriftIcon = () => (
  <div className="relative w-7 h-7 flex items-center justify-center">
    <motion.div
      className="absolute w-full h-[1px] bg-purple-500/20"
      animate={{ scaleX: [0.5, 1.4, 0.5] }}
      transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
    />
    {/* Micro branch node sliding / drifting aside */}
    <motion.div
      animate={{
        x: [-3, 3, -3],
        y: [-1, 1, -1],
        scale: [1, 1.12, 1]
      }}
      transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
    >
      <GitFork className="w-4 h-4 text-purple-400 drop-shadow-[0_0_8px_rgba(168,85,247,0.7)]" />
    </motion.div>
  </div>
);

// Animated 4: Vulnerable Code Icon
const AnimatedCodeIcon = () => (
  <div className="relative w-7 h-7 flex items-center justify-center">
    <motion.div
      className="absolute inset-[-4px] bg-red-500/10 rounded-full blur-[4px]"
      animate={{
        opacity: [0.3, 0.9, 0.3]
      }}
      transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
    />
    {/* Bug/Cross pulse heartbeat warning */}
    <motion.div
      animate={{
        scale: [1, 1.25, 1],
      }}
      transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
    >
      <Code2 className="w-4 h-4 text-rose-500 drop-shadow-[0_0_8px_rgba(244,63,94,0.73)]" />
    </motion.div>
  </div>
);

// Animated 5: Human Dependency Icon
const AnimatedUserIcon = () => (
  <div className="relative w-7 h-7 flex items-center justify-center">
    <motion.div
      className="absolute inset-0 border border-cyan-500/30 rounded-full"
      animate={{
        scale: [1, 1.4, 1],
        opacity: [0.5, 0, 0.5]
      }}
      transition={{ repeat: Infinity, duration: 3.5, ease: "easeOut" }}
    />
    <motion.div
      animate={{
        y: [-2, 2, -2],
        opacity: [1, 0.6, 1]
      }}
      transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
    >
      <UserMinus className="w-4 h-4 text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.7)]" />
    </motion.div>
  </div>
);

// Animated 6: Fragmented Workflows Icon
const AnimatedWorkflowIcon = () => (
  <div className="relative w-7 h-7 flex items-center justify-center">
    <motion.div
      className="absolute inset-0 border border-dotted border-fuchsia-500/40 rounded-full"
      animate={{ rotate: 360 }}
      transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
    />
    {/* Micro node elements syncing together */}
    <motion.div
      animate={{
        scale: [0.95, 1.15, 0.95],
        rotate: [-3, 3, -3]
      }}
      transition={{ repeat: Infinity, duration: 3.2, ease: "easeInOut" }}
    >
      <Network className="w-4 h-4 text-fuchsia-400 drop-shadow-[0_0_8px_rgba(232,121,249,0.7)]" />
    </motion.div>
  </div>
);

export default function SlideChallenges({ isActive }: SlideProps) {
  if (!isActive) return null;

  const [activeNode, setActiveNode] = useState(0);
  const autoCycleRef = useRef<NodeJS.Timeout | null>(null);

  // Symmetrical hexagons calculation at strictly equal angles (360 / 6 = 60 degrees).
  // Hallucinations is aligned at 0 degrees (pointing straight up from center).
  // Positions are calculated beautifully using R_x = 30%, R_y = 30% for high symmetry.
  const nodes = [
    {
      id: 0,
      title: "Hallucinations",
      icon: AnimatedBrainIcon,
      color: "from-rose-500/20 to-red-600/30",
      borderColor: "border-red-500/40",
      top: "13%",   
      left: "44%",  
      delay: 0.05,
    },
    {
      id: 1,
      title: "Governance Gaps",
      icon: AnimatedGovernanceIcon,
      color: "from-amber-500/20 to-amber-600/30",
      borderColor: "border-amber-500/40",
      top: "34%",   
      left: "81%", 
      delay: 0.1,
    },
    {
      id: 2,
      title: "Requirement Drift",
      icon: AnimatedDriftIcon,
      color: "from-purple-500/20 to-indigo-600/30",
      borderColor: "border-indigo-500/40",
      top: "66%",   
      left: "81%", 
      delay: 0.15,
    },
    {
      id: 3,
      title: "Vulnerable Code",
      icon: AnimatedCodeIcon,
      color: "from-red-500/20 to-rose-600/30",
      borderColor: "border-rose-500/40",
      top: "85%",   
      left: "44%",  
      delay: 0.2,
    },
    {
      id: 4,
      title: "Human Dependency",
      icon: AnimatedUserIcon,
      color: "from-cyan-500/20 to-teal-600/30",
      borderColor: "border-cyan-500/40",
      top: "66%",   
      left: "16%", 
      delay: 0.25,
    },
    {
      id: 5,
      title: "Fragmented Workflows",
      icon: AnimatedWorkflowIcon,
      color: "from-purple-500/20 to-fuchsia-600/30",
      borderColor: "border-fuchsia-500/40",
      top: "34%",   
      left: "16%", 
      delay: 0.3,
    },
  ];

  // Auto-cycle through threat metrics
  useEffect(() => {
    autoCycleRef.current = setInterval(() => {
      setActiveNode((prev) => (prev + 1) % 6);
    }, 4500);

    return () => {
      if (autoCycleRef.current) clearInterval(autoCycleRef.current);
    };
  }, []);

  const outerLabels = [
    { text: "AI-PIPELINE SECURE", position: "top-10 left-12" },
    { text: "LEGAL COMPLIANCE GATEWAY", position: "top-10 right-12" },
    { text: "SDLC SCALABILITY ENGINE", position: "bottom-12 left-12" },
    { text: "ZERO-TRUST INFRASTRUCTURE", position: "bottom-12 right-12" },
  ];

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-12 md:p-16 select-none bg-gradient-to-b from-[#030303] via-[#09090b] to-[#030303] overflow-hidden">
      
      {/* Background Sweet Ambient Glow Layers */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[550px] h-[550px] bg-red-950/10 rounded-full blur-[140px] mix-blend-screen animate-pulse" style={{ animationDuration: "14s" }} />
        <div className="absolute bottom-1/4 right-1/4 w-[450px] h-[450px] bg-purple-950/10 rounded-full blur-[110px] mix-blend-screen animate-pulse" style={{ animationDuration: "20s" }} />
        <div className="grid-bg absolute inset-0 opacity-20 pointer-events-none" />
      </div>

      {/* Cybernetic HUD Markers */}
      {outerLabels.map((lbl, idx) => (
        <motion.div
          key={idx}
          className={`${lbl.position} absolute text-[11px] font-mono tracking-[0.25em] text-gray-500/40 font-semibold border-l border-red-500/20 pl-2 pointer-events-none hidden sm:block`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 + idx * 0.1, duration: 1 }}
        >
          {lbl.text}
        </motion.div>
      ))}

      {/* Header */}
      <div className="relative z-10 space-y-3">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex items-center space-x-2"
        >
          <span className="h-[1px] w-8 bg-gradient-to-r from-red-500 to-transparent"></span>
          <span className="text-xs font-mono tracking-[0.3em] font-semibold text-red-500 uppercase">
            Phase 01 — Architectural Vulnerabilities
          </span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
          className="text-4xl md:text-5xl lg:text-6xl font-display font-light tracking-tight text-white max-w-4xl"
        >
          Current Challenges in <span className="font-semibold bg-gradient-to-r from-white via-gray-200 to-red-400 bg-clip-text text-transparent animate-pulse" style={{ animationDuration: "6s" }}>AI-Driven SDLC</span>
        </motion.h1>
      </div>

      {/* Perfect Highly Polished Symmetrical Symmetrical Symmetrical Regular Hexagonal Layout */}
      <div className="relative w-full flex-grow flex items-center justify-center min-h-[380px] lg:min-h-[460px] z-10">
        
        {/* SVG Laser paths from exact center coordinates */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
          <defs>
            <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(244, 63, 94, 0.45)" />
              <stop offset="50%" stopColor="rgba(168, 85, 247, 0.25)" />
              <stop offset="100%" stopColor="rgba(239, 68, 68, 0.45)" />
            </linearGradient>
            <radialGradient id="meshGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(239, 68, 68, 0.08)" />
              <stop offset="100%" stopColor="rgba(0,0,0,0)" />
            </radialGradient>
          </defs>
          
          <circle cx="50%" cy="50%" r="150" fill="url(#meshGlow)" />
          
          {/* Circular orbital sweep indicators */}
          <motion.circle 
            cx="50%" 
            cy="50%" 
            r="160" 
            fill="none" 
            stroke="rgba(239, 68, 68, 0.08)" 
            strokeWidth="1"
            strokeDasharray="4 12"
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 60, ease: "linear" }}
            className="origin-center"
          />
          <motion.circle 
            cx="50%" 
            cy="50%" 
            r="230" 
            fill="none" 
            stroke="rgba(168, 85, 247, 0.05)" 
            strokeWidth="1"
            strokeDasharray="6 24"
            animate={{ rotate: -360 }}
            transition={{ repeat: Infinity, duration: 90, ease: "linear" }}
            className="origin-center"
          />
          
          {/* Symmetrical signal vectors from Center (50%, 50%) to surrounding nodes */}
          {nodes.map((node) => {
            const isCurrentlyActive = node.id === activeNode;
            return (
              <g key={node.id}>
                {/* Background router path link */}
                <line
                  x1="50%"
                  y1="50%"
                  x2={node.left}
                  y2={node.top}
                  stroke={isCurrentlyActive ? "rgba(239, 68, 68, 0.22)" : "rgba(255, 255, 255, 0.04)"}
                  strokeWidth="1.5"
                  className="transition-colors duration-500"
                />
                
                {/* Laser data tracking beam */}
                <motion.line
                  x1="50%"
                  y1="50%"
                  x2={node.left}
                  y2={node.top}
                  stroke="url(#lineGrad)"
                  strokeWidth={isCurrentlyActive ? "2.2" : "1"}
                  strokeDasharray="8 16"
                  initial={{ strokeDashoffset: 0 }}
                  animate={{ strokeDashoffset: -50 }}
                  transition={{
                    repeat: Infinity,
                    duration: isCurrentlyActive ? 2 : 4.5,
                    ease: "linear",
                  }}
                />
                
                {/* Flow particles */}
                {isCurrentlyActive && (
                  <motion.circle
                    r="4.5"
                    fill="#f43f5e"
                    initial={{ cx: "50%", cy: "50%" }}
                    animate={{ cx: node.left, cy: node.top }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: "easeIn" }}
                    className="shadow-[0_0_12px_rgba(244,63,94,0.8)]"
                  />
                )}
              </g>
            );
          })}
        </svg>

        {/* Center Quantum Core Stage */}
        <motion.div
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="relative z-10 flex flex-col items-center justify-center p-6 rounded-full border border-red-500/25 bg-[#070709]/95 w-36 h-36 md:w-40 md:h-40 text-center shadow-[0_0_60px_rgba(239,68,68,0.2)]"
        >
          <div className="absolute inset-[-4px] rounded-full border border-red-500/10 animate-ping opacity-20" style={{ animationDuration: "5s" }} />
          <AdvancedCoreIcon />
          <span className="text-[9px] font-mono tracking-[0.25em] text-red-400 font-bold uppercase pointer-events-none mt-1">CORE CONCEPT</span>
          <span className="text-xs md:text-sm font-semibold text-white tracking-wide font-display mt-0.5 pointer-events-none leading-tight">AI-Driven<br />SDLC</span>
        </motion.div>

        {/* Regular Symmetrical Spaced Symmetrical Risk Nodes (Hexagon Layout) */}
        {nodes.map((node) => {
          const NodeWidget = node.icon;
          const isCurrentlyActive = node.id === activeNode;
          
          return (
            <motion.div
              key={node.id}
              className={`absolute z-10 flex items-center space-x-3.5 p-3 px-4 rounded-xl border transition-all duration-700 cursor-pointer w-[14.5rem] md:w-[16.5rem] ${
                isCurrentlyActive 
                  ? "border-red-500/40 bg-[#0e0e11]/95 shadow-[0_8px_30px_-5px_rgba(239,68,68,0.25)] scale-105" 
                  : "border-white/[0.04] bg-[#060608]/85 hover:bg-[#0c0c0f]/90 hover:scale-102"
              }`}
              style={{
                top: node.top,
                left: node.left,
                transform: "translate(-50%, -50%)",
              }}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: node.delay, duration: 0.6 }}
              onClick={() => setActiveNode(node.id)}
              onMouseEnter={() => setActiveNode(node.id)}
            >
              {/* Custom Super Animated Cyber Icons */}
              <div className={`p-1.5 rounded-lg bg-[#0d0d12]/90 border border-white/[0.08] flex-shrink-0 transition-all duration-500 ${
                isCurrentlyActive ? "border-red-500/40" : ""
              }`}>
                <NodeWidget />
              </div>
              
              <div className="min-w-0 flex-grow">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs md:text-sm font-semibold text-white tracking-wide font-display">{node.title}</h3>
                  {isCurrentlyActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                  )}
                </div>
                
                {/* Visual Status Indicator Progress Bar */}
                <div className="w-full h-[2px] bg-white/[0.05] rounded-full mt-2.5 overflow-hidden">
                  <motion.div 
                    className="h-full bg-gradient-to-r from-red-500 to-rose-400"
                    initial={{ width: "25%" }}
                    animate={{ width: isCurrentlyActive ? "100%" : "25%" }}
                    transition={{ duration: 0.8 }}
                  />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Bottom Statement Section */}
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between border-t border-white/[0.04] pt-6 gap-4">
        <motion.div
          initial={{ opacity: 0, x: -25 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex items-center space-x-3"
        >
          <div className="p-1 rounded bg-red-950/40 border border-red-500/20">
            <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
          </div>
          <p className="text-xs font-mono uppercase tracking-widest text-red-500 font-bold">
            Risk Mitigation Active
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 25 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-right"
        >
          <p className="text-sm md:text-base font-display font-light text-gray-300">
            “Enterprise AI adoption requires structured <span className="font-medium text-white">orchestration and governance</span>.”
          </p>
        </motion.div>
      </div>
    </div>
  );
}
