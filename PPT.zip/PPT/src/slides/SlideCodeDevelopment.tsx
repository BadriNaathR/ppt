import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Upload, Scissors, FileCode, FileType, Code2, ShieldCheck, GitMerge } from "lucide-react";
import { SlideProps } from "../types";

const N_BLOCKS = 4;
const NODE_R = 34;

/* ── fixed node positions (%) ── */
const INTAKE_X = 7;
const SPLIT_X  = 24;
const UNIT_X   = 52;
const BUILD_X  = 78;
const SHIP_X   = 93;

const unitY = (i: number) =>
  N_BLOCKS === 1 ? 50 : 12 + (i * 76) / (N_BLOCKS - 1);

/* ── edge label positions (midpoint offset) ── */
type EdgeDef = { id: string; from: number; to: number; label?: string; labelColor?: string };

const EDGES: EdgeDef[] = [
  { id: "e01", from: 0, to: 1, label: "Design Docs", labelColor: "#06b6d4" },
  ...Array.from({ length: N_BLOCKS }, (_, i) => ({
    id: `e1u${i}`, from: 1, to: 2 + i, label: "Spec .md", labelColor: "#818cf8",
  })),
  ...Array.from({ length: N_BLOCKS }, (_, i) => ({
    id: `eu${i}b`, from: 2 + i, to: 2 + N_BLOCKS, label: "DSL YAML", labelColor: "#38bdf8",
  })),
  { id: "ebs", from: 2 + N_BLOCKS, to: 3 + N_BLOCKS },
];

/* ── node meta (non-unit nodes) ── */
const STATIC_NODES = [
  {
    id: 0, icon: Upload, label: "User Story\n+ Design Intake", tag: "INPUT",
    color: "#06b6d4", glow: "rgba(6,182,212,0.45)",
    x: INTAKE_X, y: 50,
    tooltip: "Upload User Story & Design",
  },
  {
    id: 1, icon: Scissors, label: "Splitting\nAgent", tag: "SPLIT",
    color: "#818cf8", glow: "rgba(129,140,248,0.45)",
    x: SPLIT_X, y: 50,
    tooltip: "Logically splits user story into independent units",
  },
  {
    id: 2 + N_BLOCKS, icon: ShieldCheck, label: "Validation\n& Synthesis", tag: "BUILD",
    color: "#a78bfa", glow: "rgba(167,139,250,0.45)",
    x: BUILD_X, y: 50,
    tooltip: null,
  },
  {
    id: 3 + N_BLOCKS, icon: GitMerge, label: "Merge &\nDeploy", tag: "SHIP",
    color: "#34d399", glow: "rgba(52,211,153,0.5)",
    x: SHIP_X, y: 50,
    tooltip: null,
  },
];

/* ── unit card sub-rows ── */
const UNIT_ROWS = [
  { icon: FileType,  label: "Design Docs",  color: "#06b6d4", note: "from Intake" },
  { icon: FileCode,  label: "Spec .md",     color: "#818cf8", note: "from Splitting Agent" },
  { icon: Code2,     label: "DSL YAML",     color: "#38bdf8", note: "generated" },
];

function TravelDot({ x1, y1, x2, y2, color }: { x1:number; y1:number; x2:number; y2:number; color:string }) {
  return (
    <circle r={3} fill={color} style={{ filter: `drop-shadow(0 0 4px ${color})` }}>
      <animateMotion dur="1.8s" repeatCount="indefinite" path={`M${x1} ${y1} L${x2} ${y2}`} />
    </circle>
  );
}

export default function SlideCodeDevelopment({ isActive }: SlideProps) {
  const [active, setActive] = useState(0);
  const [autoRun, setAutoRun] = useState(true);
  const [hovered, setHovered] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dim, setDim] = useState({ w: 900, h: 420 });

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setDim({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setDim({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  const totalNodes = 2 + N_BLOCKS + 2;
  useEffect(() => {
    if (!isActive || !autoRun) return;
    const t = setInterval(() => setActive(p => (p + 1) % totalNodes), 2200);
    return () => clearInterval(t);
  }, [isActive, autoRun, totalNodes]);

  if (!isActive) return null;

  /* pixel helpers */
  const cpx = (xPct: number) => (xPct / 100) * dim.w;
  const cpy = (yPct: number) => (yPct / 100) * dim.h;

  /* all node positions for edge drawing */
  const allPos: Record<number, { cx: number; cy: number }> = {};
  STATIC_NODES.forEach(n => { allPos[n.id] = { cx: cpx(n.x), cy: cpy(n.y) }; });
  Array.from({ length: N_BLOCKS }, (_, i) => {
    allPos[2 + i] = { cx: cpx(UNIT_X), cy: cpy(unitY(i)) };
  });

  const liveEdge = (e: EdgeDef) => e.from === active || e.to === active;
  const activeColor = active < STATIC_NODES.length + N_BLOCKS
    ? (STATIC_NODES.find(n => n.id === active)?.color ?? "#38bdf8")
    : "#38bdf8";

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-6 md:p-10 select-none bg-gradient-to-b from-[#030303] via-[#07070b] to-[#030303] overflow-hidden">

      {/* Ambient glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div className="absolute rounded-full blur-[140px]"
          animate={{
            left: `${allPos[active]?.cx ?? cpx(50)}px`,
            top:  `${allPos[active]?.cy ?? cpy(50)}px`,
            background: `radial-gradient(circle, ${activeColor}33 0%, transparent 65%)`,
          }}
          transition={{ duration: 0.9, ease: "easeInOut" }}
          style={{ width: 480, height: 480, transform: "translate(-50%,-50%)" }} />
        <div className="grid-bg absolute inset-0 opacity-[0.12]" />
      </div>

      {/* Header */}
      <div className="relative z-10 space-y-0.5 mb-1">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
          className="flex items-center space-x-2">
          <span className="h-px w-7 bg-gradient-to-r from-indigo-500 to-transparent" />
          <span className="text-[10px] font-mono tracking-[0.3em] font-semibold text-indigo-400 uppercase">
            Phase 04 — Governed AI Workflow
          </span>
        </motion.div>
        <motion.h1 initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.08 }}
          className="text-2xl md:text-3xl font-display font-light tracking-tight text-white">
          AI-SDLC{" "}
          <span className="font-semibold bg-gradient-to-r from-white via-indigo-100 to-indigo-400 bg-clip-text text-transparent">
            Node Workflow
          </span>
        </motion.h1>
      </div>

      {/* Graph canvas */}
      <div ref={containerRef} className="relative z-10 flex-grow w-full">

        {/* SVG edges */}
        <svg className="absolute inset-0 w-full h-full" style={{ overflow: "visible" }}>
          <defs>
            <marker id="arr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <path d="M0,0 L0,6 L6,3 z" fill="rgba(99,102,241,0.5)" />
            </marker>
          </defs>

          {EDGES.map(e => {
            const f = allPos[e.from];
            const t = allPos[e.to];
            if (!f || !t) return null;
            const live = liveEdge(e);
            const fromColor = STATIC_NODES.find(n => n.id === e.from)?.color ?? "#38bdf8";

            /* shorten to node border — unit cards are wider so use card half-width for unit nodes */
            const isFromUnit = e.from >= 2 && e.from < 2 + N_BLOCKS;
            const isToUnit   = e.to   >= 2 && e.to   < 2 + N_BLOCKS;
            const fromR = isFromUnit ? dim.w * 0.095 : NODE_R;
            const toR   = isToUnit   ? dim.w * 0.095 : NODE_R;

            const dx = t.cx - f.cx, dy = t.cy - f.cy;
            const len = Math.sqrt(dx*dx + dy*dy) || 1;
            const ux = dx/len, uy = dy/len;
            const x1 = f.cx + ux * fromR, y1 = f.cy + uy * fromR;
            const x2 = t.cx - ux * toR,   y2 = t.cy - uy * toR;
            const mx = (x1+x2)/2, my = (y1+y2)/2;

            return (
              <g key={e.id}>
                <line x1={x1} y1={y1} x2={x2} y2={y2}
                  stroke="rgba(99,102,241,0.08)" strokeWidth={1.5} markerEnd="url(#arr)" />
                <motion.line x1={x1} y1={y1} x2={x2} y2={y2}
                  stroke={live ? fromColor : "rgba(99,102,241,0.15)"}
                  strokeWidth={live ? 2 : 1}
                  strokeDasharray="8 14"
                  animate={{ strokeDashoffset: [0, -44] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: "linear" }}
                  style={{ filter: live ? `drop-shadow(0 0 3px ${fromColor})` : "none" }} />
                {live && <TravelDot x1={x1} y1={y1} x2={x2} y2={y2} color={fromColor} />}

                {/* edge label */}
                {e.label && (
                  <motion.text x={mx} y={my - 5} textAnchor="middle"
                    fontSize="8" fontFamily="JetBrains Mono, monospace" fontWeight="600"
                    fill={live ? (e.labelColor ?? "#818cf8") : "rgba(255,255,255,0.12)"}
                    style={{ filter: live ? `drop-shadow(0 0 4px ${e.labelColor})` : "none" }}
                    animate={{ opacity: live ? 1 : 0.4 }}
                    transition={{ duration: 0.3 }}>
                    {e.label}
                  </motion.text>
                )}
              </g>
            );
          })}
        </svg>

        {/* ── Static circle nodes (Intake, Split, Build, Ship) ── */}
        {STATIC_NODES.map(n => {
          const { cx, cy } = allPos[n.id];
          const isAct = active === n.id;
          const isHov = hovered === n.id;
          const Icon = n.icon;
          return (
            <motion.div key={n.id}
              className="absolute flex flex-col items-center cursor-pointer"
              style={{ left: cx, top: cy, transform: "translate(-50%,-50%)", zIndex: 20 }}
              animate={{ scale: isAct ? 1.12 : 1 }}
              transition={{ duration: 0.3 }}
              onClick={() => { setActive(n.id); setAutoRun(false); }}
              onMouseEnter={() => setHovered(n.id)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* pulse halo */}
              <AnimatePresence>
                {isAct && (
                  <motion.div className="absolute rounded-full pointer-events-none"
                    style={{ width: NODE_R*2+24, height: NODE_R*2+24, top:"50%", left:"50%",
                      transform:"translate(-50%,-50%)",
                      background:`radial-gradient(circle, ${n.glow} 0%, transparent 70%)` }}
                    initial={{ opacity:0, scale:0.7 }}
                    animate={{ opacity:[0.7,0.15,0.7], scale:[1,1.3,1] }}
                    exit={{ opacity:0 }}
                    transition={{ duration:1.8, repeat:Infinity }} />
                )}
              </AnimatePresence>

              {/* circle */}
              <motion.div className="relative flex flex-col items-center justify-center rounded-full border-2 overflow-hidden"
                style={{ width: NODE_R*2, height: NODE_R*2 }}
                animate={{
                  borderColor: isAct ? n.color : isHov ? n.color+"70" : "rgba(255,255,255,0.07)",
                  background: isAct ? `radial-gradient(circle at 38% 38%, ${n.color}28, #090910)` : isHov ? `${n.color}10` : "#090910",
                  boxShadow: isAct ? `0 0 20px ${n.glow}` : "none",
                }}
                transition={{ duration: 0.3 }}>
                {isAct && (
                  <motion.div className="absolute left-0 right-0 h-px pointer-events-none"
                    style={{ background:`linear-gradient(90deg,transparent,${n.color},transparent)` }}
                    initial={{ top:"10%" }} animate={{ top:"90%" }}
                    transition={{ duration:1.5, repeat:Infinity, ease:"easeInOut" }} />
                )}
                <Icon className="w-4 h-4 mb-0.5" style={{ color: isAct ? n.color : "#374151" }} />
                <span className="text-[7px] font-mono font-bold text-center px-1"
                  style={{ color: isAct ? n.color : "#4b5563" }}>{n.tag}</span>
              </motion.div>

              {/* label */}
              <motion.span className="mt-1 text-[9px] font-display font-semibold text-center leading-tight whitespace-pre-line"
                style={{ maxWidth: 68 }}
                animate={{ color: isAct ? "#fff" : "#374151" }}
                transition={{ duration: 0.3 }}>
                {n.label}
              </motion.span>

              {/* tooltip */}
              <AnimatePresence>
                {isHov && n.tooltip && (
                  <motion.div className="absolute bottom-full mb-2 px-2.5 py-1.5 rounded-lg border text-[9px] font-mono font-semibold whitespace-nowrap pointer-events-none z-50"
                    style={{ borderColor: n.color+"55", background:"#0d0d14", color: n.color, boxShadow:`0 0 14px ${n.glow}` }}
                    initial={{ opacity:0, y:5, scale:0.92 }} animate={{ opacity:1, y:0, scale:1 }}
                    exit={{ opacity:0, y:4 }} transition={{ duration:0.18 }}>
                    {n.tooltip}
                    <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0"
                      style={{ borderLeft:"4px solid transparent", borderRight:"4px solid transparent", borderTop:`4px solid ${n.color}55` }} />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}

        {/* ── Work-unit expanded cards ── */}
        {Array.from({ length: N_BLOCKS }, (_, i) => {
          const nodeId = 2 + i;
          const { cx, cy } = allPos[nodeId];
          const isAct = active === nodeId;
          const isHov = hovered === nodeId;
          const cardW = dim.w * 0.19;
          const cardH = 88;
          const color = "#38bdf8";
          const glow  = "rgba(56,189,248,0.4)";

          return (
            <motion.div key={nodeId}
              className="absolute cursor-pointer"
              style={{ left: cx, top: cy, transform: "translate(-50%,-50%)", zIndex: 20, width: cardW }}
              animate={{ scale: isAct ? 1.06 : 1 }}
              transition={{ duration: 0.3 }}
              onClick={() => { setActive(nodeId); setAutoRun(false); }}
              onMouseEnter={() => setHovered(nodeId)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* halo */}
              <AnimatePresence>
                {isAct && (
                  <motion.div className="absolute inset-0 rounded-xl pointer-events-none"
                    style={{ background:`radial-gradient(ellipse, ${glow} 0%, transparent 70%)`, margin:-10 }}
                    initial={{ opacity:0 }} animate={{ opacity:[0.6,0.15,0.6] }}
                    exit={{ opacity:0 }} transition={{ duration:1.8, repeat:Infinity }} />
                )}
              </AnimatePresence>

              <motion.div className="relative rounded-xl border-2 overflow-hidden"
                style={{ height: cardH }}
                animate={{
                  borderColor: isAct ? color : isHov ? color+"60" : "rgba(255,255,255,0.07)",
                  background: isAct ? `linear-gradient(135deg, ${color}14, #090910)` : isHov ? `${color}08` : "#090910",
                  boxShadow: isAct ? `0 0 18px ${glow}` : "none",
                }}
                transition={{ duration: 0.3 }}>

                {/* scan line */}
                {isAct && (
                  <motion.div className="absolute left-0 right-0 h-px pointer-events-none"
                    style={{ background:`linear-gradient(90deg,transparent,${color},transparent)` }}
                    initial={{ top:"0%" }} animate={{ top:"100%" }}
                    transition={{ duration:1.4, repeat:Infinity, ease:"easeInOut" }} />
                )}

                {/* card header */}
                <div className="flex items-center justify-between px-2.5 pt-2 pb-1 border-b"
                  style={{ borderColor: isAct ? color+"30" : "rgba(255,255,255,0.05)" }}>
                  <span className="text-[9px] font-mono font-bold" style={{ color: isAct ? color : "#4b5563" }}>
                    WU-{String(i+1).padStart(2,"0")}
                  </span>
                  <span className="text-[9px] font-display font-semibold" style={{ color: isAct ? "#fff" : "#374151" }}>
                    Unit {i+1}
                  </span>
                </div>

                {/* sub-rows */}
                <div className="flex flex-col gap-0.5 px-2 py-1.5">
                  {UNIT_ROWS.map((row, ri) => {
                    const RowIcon = row.icon;
                    return (
                      <motion.div key={ri} className="flex items-center gap-1.5"
                        initial={{ opacity:0, x:6 }} animate={{ opacity:1, x:0 }}
                        transition={{ delay: ri * 0.07 }}>
                        <RowIcon className="w-2.5 h-2.5 shrink-0" style={{ color: isAct ? row.color : "#374151" }} />
                        <span className="text-[8px] font-mono leading-tight" style={{ color: isAct ? row.color : "#374151" }}>
                          {row.label}
                        </span>
                        <span className="text-[7px] font-mono leading-tight ml-auto" style={{ color: isAct ? "#6b7280" : "#1f2937" }}>
                          {row.note}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            </motion.div>
          );
        })}

        {/* …N hint */}
        {(() => {
          const last = allPos[1 + N_BLOCKS];
          if (!last) return null;
          return (
            <motion.div className="absolute pointer-events-none font-mono text-[10px] font-bold"
              style={{ left: last.cx + dim.w*0.1 + 4, top: last.cy - 5, color:"#38bdf8" }}
              animate={{ opacity:[0.25,0.65,0.25] }} transition={{ duration:2.4, repeat:Infinity }}>
              …N
            </motion.div>
          );
        })()}
      </div>

      {/* Footer */}
      <div className="relative z-10 flex items-center justify-between border-t border-white/[0.04] pt-2 mt-1">
        <div className="flex items-center gap-2">
          <motion.div className="w-1.5 h-1.5 rounded-full"
            style={{ background: autoRun ? "#34d399" : "#6b7280" }}
            animate={autoRun ? { scale:[1,1.7,1], opacity:[1,0.3,1] } : {}}
            transition={{ duration:1.1, repeat:Infinity }} />
          <span className="text-[9px] font-mono tracking-widest text-gray-500 uppercase">
            {autoRun ? "Auto-walking nodes" : `Node ${active+1} / ${totalNodes} — click any node`}
          </span>
        </div>
        <p className="text-[10px] font-display font-light text-gray-500">
          "From intent to <span className="text-white font-medium">governed delivery</span>."
        </p>
      </div>
    </div>
  );
}
