import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileText, 
  ArrowRight, 
  Shuffle, 
  Users, 
  CreditCard, 
  Bell, 
  CheckSquare,
  Sparkles,
  Command
} from "lucide-react";
import { SlideProps } from "../types";

export default function SlideStoryIntelligence({ isActive }: SlideProps) {
  if (!isActive) return null;

  const stories = [
    {
      id: "US-101",
      title: "Authentication Flow",
      desc: "Secure multi-factor enterprise login pipeline",
      icon: Users,
      badge: "Security",
      glow: "from-cyan-500/15 via-blue-500/10 to-transparent"
    },
    {
      id: "US-102",
      title: "Payment Workflow",
      desc: "Highly-auditable ledger synchronization",
      icon: CreditCard,
      badge: "Commerce",
      glow: "from-blue-500/15 via-indigo-500/10 to-transparent"
    },
    {
      id: "US-103",
      title: "Notification Module",
      desc: "Distributed event-driven messaging layer",
      icon: Bell,
      badge: "Core Service",
      glow: "from-indigo-500/15 via-purple-500/10 to-transparent"
    },
    {
      id: "US-104",
      title: "Approval Engine",
      desc: "Multi-layered consensus governance controller",
      icon: CheckSquare,
      badge: "Compliance",
      glow: "from-purple-500/15 via-rose-500/10 to-transparent"
    }
  ];

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-12 md:p-16 select-none bg-gradient-to-b from-[#030303] via-[#09090b] to-[#030303] overflow-hidden">
      
      {/* Background Grid & Ambient Blue Pulse */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/3 w-[600px] h-[600px] bg-blue-950/10 rounded-full blur-[140px] mix-blend-screen animate-pulse" style={{ animationDuration: "14s" }} />
        <div className="grid-bg absolute inset-0 opacity-20 pointer-events-none" />
      </div>

      {/* Header */}
      <div className="relative z-10 space-y-3">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex items-center space-x-2"
        >
          <span className="h-[1px] w-8 bg-gradient-to-r from-blue-500 to-transparent"></span>
          <span className="text-xs font-mono tracking-[0.3em] font-semibold text-blue-400 uppercase">
            Phase 03 — Requirements Parsing
          </span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
          className="text-4xl md:text-5xl lg:text-6xl font-display font-light tracking-tight text-white max-w-4xl"
        >
          From Business Intent to <span className="font-semibold bg-gradient-to-r from-white via-cyan-100 to-blue-400 bg-clip-text text-transparent">Structured User Stories</span>
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="text-gray-400 text-sm md:text-base tracking-wide max-w-xl font-light"
        >
          AI transforms unstructured requirements documents into fully traceable, modular engineering backlogs.
        </motion.p>
      </div>

      {/* Left to Right Flow Container */}
      <div className="relative w-full flex-grow grid grid-cols-12 gap-8 items-center min-h-[350px] lg:min-h-[420px] z-10">
        
        {/* Left Side: Business Requirements Card */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="col-span-12 md:col-span-4 p-5 rounded-2xl border border-white/[0.08] bg-[#0b0b0d]/90 relative h-72 md:h-80 flex flex-col justify-between shadow-[0_15px_35px_rgba(0,0,0,0.5)] group overflow-hidden"
        >
          {/* subtle line highlights */}
          <div className="absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b from-blue-500 to-cyan-500" />
          
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-400" />
                <span className="text-xs font-mono tracking-widest text-gray-400 font-bold">SOURCE DATA</span>
              </div>
              <span className="text-[10px] font-mono text-cyan-400/80 px-2 py-0.5 rounded border border-cyan-500/20 bg-cyan-950/20 font-semibold uppercase">PDF / DOCX</span>
            </div>
            
            <h3 className="text-sm md:text-base font-semibold text-white mb-3 font-display">Business Requirements Document (BRD)</h3>
            
            {/* Visual NLP Parsing lines simulation */}
            <div className="space-y-2 font-mono text-[10px] text-gray-500">
              <div className="flex items-center space-x-1 border-b border-white/[0.03] pb-1.5">
                <span className="text-blue-400"># intent:</span>
                <span className="text-gray-300">"Build enterprise-ready modular checkout..."</span>
              </div>
              <div className="flex items-center space-x-1 border-b border-white/[0.03] pb-1.5">
                <span className="text-cyan-400"># auth:</span>
                <span className="text-gray-400">"SAML, SSO and multifactor approval guards."</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-purple-400"># compliant:</span>
                <span className="text-gray-400">"Enable auditable, non-repudiary logs..."</span>
              </div>
            </div>
          </div>

          {/* Glowing bottom metadata */}
          <div className="mt-4 flex items-center justify-between text-[11px] text-gray-400 font-mono">
            <span>Size: 45 KB</span>
            <span className="flex items-center space-x-1 text-cyan-400">
              <span>Status: Scanned</span>
              <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping" />
            </span>
          </div>

          {/* Scanning glow bar effect */}
          <motion.div 
            className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-60"
            initial={{ top: "0%" }}
            animate={{ top: "100%" }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          />
        </motion.div>

        {/* Center Side: Pipeline Animation */}
        <div className="col-span-12 md:col-span-4 h-full flex flex-col justify-center items-center relative py-6">
          
          {/* Thin connection guide line */}
          <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-gradient-to-r from-blue-500/20 via-cyan-500/30 to-purple-500/20 -translate-y-1/2 hidden md:block" />

          {/* Main Processing Hub */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative z-10 flex flex-col items-center justify-center p-5 rounded-2xl border border-blue-500/20 bg-[#0e0e12]/95 text-center w-40 h-40 shadow-[0_0_40px_rgba(6,182,212,0.1)] group"
          >
            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-blue-500 via-cyan-400 to-purple-500 opacity-20 blur-md group-hover:opacity-40 transition-opacity duration-300 pointer-events-none" />
            <Sparkles className="w-8 h-8 text-cyan-400 animate-pulse mb-2" />
            <span className="text-[10px] font-mono tracking-widest text-cyan-400 font-bold uppercase">AI ANALYZER</span>
            <span className="text-xs text-white/90 font-medium tracking-wide mt-1 font-display">Semantics Engine</span>
            
            {/* Horizontal Flow Arrow inside */}
            <div className="flex items-center space-x-1 mt-2">
              <span className="w-1 h-1 bg-blue-400 rounded-full animate-ping" />
              <ArrowRight className="w-3.5 h-3.5 text-gray-400" />
            </div>
          </motion.div>

          {/* Tiny moving telemetry stars */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden hidden md:block">
            {Array.from({ length: 3 }).map((_, inx) => (
              <motion.div
                key={inx}
                className="absolute w-1.5 h-1.5 bg-gradient-to-r from-blue-400 to-cyan-300 rounded-full"
                style={{ top: `${45 + inx * 5}%` }}
                initial={{ left: "10%", opacity: 0 }}
                animate={{ left: "90%", opacity: [0, 1, 1, 0] }}
                transition={{
                  duration: 2.8,
                  repeat: Infinity,
                  delay: inx * 0.9,
                  ease: "easeInOut"
                }}
              />
            ))}
          </div>

        </div>

        {/* Right Side: Generated Stories Stack */}
        <div className="col-span-12 md:col-span-4 space-y-3 max-h-[300px] md:max-h-none overflow-y-auto pr-1">
          {stories.map((story, idx) => {
            const StoryIcon = story.icon;
            return (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: idx * 0.15 }}
                whileHover={{ scale: 1.02 }}
                className="relative p-3 rounded-xl border border-white/[0.05] bg-[#0c0c0f]/90 hover:bg-[#131317]/95 transition-all duration-300 overflow-hidden group"
              >
                {/* Back subtle glow stripe */}
                <div className={`absolute inset-0 bg-gradient-to-r ${story.glow} opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none`} />
                
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-mono text-gray-500 font-bold">{story.id}</span>
                    <span className="text-[9px] font-mono text-blue-400 uppercase font-semibold tracking-wider">{story.badge}</span>
                  </div>
                  <Command className="w-3 h-3 text-cyan-500 opacity-35 group-hover:opacity-100 transition-opacity" />
                </div>
                
                <div className="flex items-start space-x-2.5">
                  <div className="p-1.5 rounded bg-gray-800/60 border border-white/[0.04] mt-0.5">
                    <StoryIcon className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                  <div>
                    <h4 className="text-xs md:text-sm font-semibold text-white font-display tracking-tight leading-snug">{story.title}</h4>
                    <p className="text-[10px] md:text-xs text-gray-400/80 leading-normal font-light mt-0.5">{story.desc}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>

      {/* Bottom Statement Section */}
      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between border-t border-white/[0.04] pt-6 gap-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex items-center space-x-3"
        >
          <div className="p-1 rounded bg-blue-950/40 border border-blue-500/20">
            <Shuffle className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <p className="text-xs font-mono uppercase tracking-widest text-blue-400 font-bold">
            Tracing Engine Active
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-right"
        >
          <p className="text-sm md:text-base font-display font-light text-gray-300">
            “Structured requirements <span className="font-medium text-white">reduce ambiguity and improve delivery accuracy</span>.”
          </p>
        </motion.div>
      </div>
    </div>
  );
}
