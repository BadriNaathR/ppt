export interface SlideProps {
  isActive: boolean;
}

export interface SlideData {
  id: number;
  title: string;
  shortTitle: string;
}
